"""
Course Project: Cryptanalysis of Side-Channel Vulnerabilities (Track D)
Author: Payal (BSCS)
Teacher: Muhammad Talha
Description: Simulates a Timing Attack on non-constant-time RSA decryption 
             and verifies the Cryptographic Blinding countermeasure.
"""

import time
import random
import statistics
import matplotlib.pyplot as plt

# ==========================================
# 1. CORE CRYPTOGRAPHIC PRIMITIVES
# ==========================================

def non_constant_time_mod_exp(base, exponent, modulus):
    """
    Simulates standard Square-and-Multiply algorithm.
    Introduces artificial sleep to robustly demonstrate the 
    computational overhead when processing bit '1' vs bit '0'.
    """
    result = 1
    base = base % modulus
    bits = bin(exponent)[2:] # Get binary string of private key
    
    for bit in bits:
        # Step 1: Square operation (Always happens)
        result = (result * result) % modulus
        time.sleep(0.0001) # Simulating baseline hardware operation time
        
        # Step 2: Multiply operation (Only happens if key bit is 1)
        if bit == '1':
            result = (result * base) % modulus
            time.sleep(0.0002) # Extra execution time leaked here
            
    return result

def constant_time_blinding_decryption(ciphertext, d, n, e):
    """
    Countermeasure: Applies Cryptographic Blinding before decryption.
    c' = (c * r^e) mod n
    Then unblinds the result: m = (m' * r^-1) mod n
    """
    # 1. Choose a random blinding factor 'r' coprime to n
    while True:
        r = random.randint(2, n - 1)
        if math_gcd(r, n) == 1:
            break
            
    # 2. Compute r^e mod n
    r_pow_e = pow(r, e, n)
    
    # 3. Blind the ciphertext
    blinded_c = (ciphertext * r_pow_e) % n
    
    # 4. Decrypt the blinded ciphertext (even with non-constant time, it leaks random data)
    blinded_m = non_constant_time_mod_exp(blinded_c, d, n)
    
    # 5. Unblind to get original message: m = (blinded_m * r^-1) mod n
    r_inv = pow(r, -1, n)
    message = (blinded_m * r_inv) % n
    
    return message

def math_gcd(a, b):
    while b:
        a, b = b, a % b
    return a

# ==========================================
# 2. EXPERIMENTAL EVALUATION ENGINE
# ==========================================

def run_experiments():
    print("[+] Initializing Cryptography Lab Experiment...")
    
    # Toy RSA Parameters for deterministic analysis
    # p=61, q=53 -> n=3233, e=17, d=2753 (Binary: 101011000001)
    n = 3233
    e = 17
    d = 2753 
    
    ciphertexts = [random.randint(100, 3000) for _ in range(50)]
    
    vulnerable_times = []
    protected_times = []
    
    print("[+] Measuring performance of Vulnerable Implementation...")
    for c in ciphertexts:
        start_time = time.perf_counter()
        _ = non_constant_time_mod_exp(c, d, n)
        vulnerable_times.append(time.perf_counter() - start_time)
        
    print("[+] Measuring performance of Protected Implementation (Blinding)...")
    for c in ciphertexts:
        start_time = time.perf_counter()
        _ = constant_time_blinding_decryption(c, d, n, e)
        protected_times.append(time.perf_counter() - start_time)
        
    # Statistical Summary
    print("\n=== EXPERIMENTAL METRICS ===")
    print(f"Vulnerable Mean Execution Time: {statistics.mean(vulnerable_times):.5f} seconds")
    print(f"Vulnerable Time Variance      : {statistics.variance(vulnerable_times):.7f}")
    print(f"Protected Mean Execution Time : {statistics.mean(protected_times):.5f} seconds")
    print(f"Protected Time Variance       : {statistics.variance(protected_times):.7f}")
    print("============================\n")
    
    generate_plots(vulnerable_times, protected_times)

def generate_plots(v_times, p_times):
    """Generates comparative charts required for technical compliance."""
    plt.figure(figsize=(10, 5))
    
    plt.plot(v_times, label='Vulnerable (Square-and-Multiply)', color='red', alpha=0.7)
    plt.plot(p_times, label='Protected (Blinded Exponentiation)', color='green', alpha=0.7)
    
    plt.title('Side-Channel Execution Time Analysis')
    plt.xlabel('Experiment Trial Matrix Index')
    plt.ylabel('Execution Time (Seconds)')
    plt.legend()
    plt.grid(True)
    
    # Save chart for IEEE Report Inclusion
    plt.savefig('side_channel_analysis.png')
    print("[+] Benchmark graph successfully exported as 'side_channel_analysis.png'")
    plt.show()

if __name__ == "__main__":
    run_experiments()